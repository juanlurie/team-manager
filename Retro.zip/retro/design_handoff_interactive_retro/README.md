# Handoff: Interactive Sprint Retro
**Repo:** `github.com/juanlurie/team-manager`
**Stack:** Angular 22 · ASP.NET Core 9 · PostgreSQL 17
**Target feature:** Retro tab on the Sprint Detail page

---

## TL;DR — The core retro UI is already built

After exploring the codebase, the recommended **B-desktop / A-phone hybrid** is already implemented
in `sprint-retro.component.ts`. The component has:

- Desktop (≥900 px): **Living Board** — 3-column board, `Next →` advances the phase for the room
- Mobile (<900 px): **Guided Stepper** — step pips, one phase per screen
- Phases: `lobby → add → vote → discuss → actions`
- WebSocket real-time (`retro_card_added`, `retro_card_deleted`, `retro_voted`,
  `retro_phase_changed`, `retro_action_*`)
- 3-vote budget per user (`myVoteCount` tracked per card)
- Cards with live author attribution
- Discuss spotlight (highest-voted card highlighted, rest dimmed, queue below)
- Action items with owner assignment + status cycling (Open → InProgress → Done)

**Do not redesign or rebuild the retro UI.** The work needed is targeted.

---

## The one real gap — Actions don't become WorkItem tasks

This is the user's primary unmet requirement:
> *"Action items will become tasks in the system assigned to someone"*

### Why it's broken today

`RetroAction` is a **separate, standalone table**. It stores `assignedTo` as a
plain `string` (the member's display name), not a `sprintMemberId`. This means:

- Actions never appear in anyone's sprint work-item list
- There is no link between a `RetroAction` and the `WorkItem` / `SprintMember` tables
- Assigning an owner on the retro board has zero effect on the actual task system

### What needs to be added

#### 1 — Backend: `RetroAction` → `WorkItem` bridge

**`Domain/Entities/RetroAction.cs`** — add two new nullable columns:
```csharp
public Guid? WorkItemId { get; set; }        // FK → WorkItems.Id (nullable)
public Guid? AssignedToSprintMemberId { get; set; }  // FK → SprintMembers.Id (nullable)
```

**New EF Core migration** to add these columns (keep `AssignedTo` string column for
backward compat — populate it from the member name on conversion).

**New endpoint** — `POST /api/retro-actions/{id}/convert-to-task`:
```json
// Request body
{ "sprintMemberId": "guid" }

// Response — updated RetroAction
{
  "id": "...",
  "workItemId": "guid-of-created-work-item",
  "assignedToSprintMemberId": "guid",
  "assignedTo": "Full Name",
  ...
}
```

Internally this endpoint should:
1. Load the `RetroAction` by id (verify it belongs to the sprint)
2. Call the existing work-item creation logic:
   ```csharp
   var workItem = new WorkItem {
     SprintMemberId = request.SprintMemberId,
     Title = action.Title,
     Type = WorkItemType.Task,
     Status = WorkItemStatus.Planned,
     Description = $"Created from retro action — Sprint {action.SprintId}"
   };
   ```
3. Set `action.WorkItemId = workItem.Id` and `action.AssignedToSprintMemberId = request.SprintMemberId`
4. Broadcast WebSocket event `retro_action_converted` with `{ sprintId, actionId, workItemId }`

**Update `PUT /api/retro-actions/{id}`** — also accept `assignedToSprintMemberId` in the
request body so the owner picker saves a proper ID, not just a string.

---

#### 2 — Frontend model update

**`retro-action.model.ts`** — add two fields:
```typescript
export interface RetroAction {
  // ... existing fields ...
  workItemId: string | null;              // populated after conversion
  assignedToSprintMemberId: string | null; // proper member ID
}

export interface CreateRetroActionRequest {
  // ... existing fields ...
  assignedToSprintMemberId: string | null;
}
```

---

#### 3 — Frontend: owner picker in `sprint-retro.component.ts`

**Current code (actions phase, desktop board):**
```html
<select class="owner-select" [ngModel]="action.assignedTo ?? ''"
        (ngModelChange)="assignOwner(action, $event)">
  <option value="">Assign…</option>
  @for (m of members; track m.teamMemberId) {
    <option [value]="m.fullName">{{ m.fullName }}</option>
  }
</select>
```

**Change to:** bind `[value]="m.sprintMemberId"` instead of `m.fullName` so the selected
value is a proper ID. Update `assignOwner()` accordingly to send
`assignedToSprintMemberId` in the PUT request.

**Add a "→ Create task" button** next to each action item (visible when `workItemId` is null):
```html
@if (!action.workItemId) {
  <button class="to-action-btn" (click)="convertAction(action)"
          [disabled]="!action.assignedToSprintMemberId">
    → Create task
  </button>
} @else {
  <span class="task-badge">✓ Task created</span>
}
```

**Add `convertAction()` method to `SprintRetroComponent`:**
```typescript
convertAction(action: RetroAction) {
  if (!action.assignedToSprintMemberId) return;
  this.actionSvc.convertToTask(action.id, action.assignedToSprintMemberId)
    .subscribe(updated =>
      this.actions.update(list => list.map(a => a.id === updated.id ? updated : a))
    );
}
```

**Add to `RetroActionService`:**
```typescript
convertToTask(actionId: string, sprintMemberId: string): Observable<RetroAction> {
  return this.http.post<RetroAction>(
    `${API_BASE}/retro-actions/${actionId}/convert-to-task`,
    { sprintMemberId }
  );
}
```

**WebSocket handler** — add in `ngOnInit`'s `wsSub`:
```typescript
if (msg.type === 'retro_action_converted') {
  this.actionSvc.getBySprintId(this.sprintId)
    .subscribe(a => this.actions.set(a));
}
```

---

#### 4 — Members input shape (minor)

The `members` input to `SprintRetroComponent` is typed as `MemberSprintCard[]`.
The owner picker needs `sprintMemberId` — verify this field exists on `MemberSprintCard`
(it does: `sprintMemberId: string`). The select option just needs to bind to it.

---

## Complete file map

### Files to edit

| File | What to change |
|---|---|
| `Domain/Entities/RetroAction.cs` | Add `WorkItemId`, `AssignedToSprintMemberId` nullable FKs |
| `Application/DTOs/` | Update `RetroActionDto`, `CreateRetroActionRequest` to include new fields |
| `Infrastructure/` | Add EF migration for two new columns |
| API controller (retro-actions) | Add `POST /{id}/convert-to-task` endpoint |
| `retro-action.model.ts` | Add `workItemId`, `assignedToSprintMemberId` to interfaces |
| `retro-action.service.ts` | Add `convertToTask(actionId, sprintMemberId)` method |
| `sprint-retro.component.ts` | Owner picker → bind `sprintMemberId`; add "→ Create task" button + `convertAction()` method; handle `retro_action_converted` WS event |

### Files to leave alone

| File | Why |
|---|---|
| `sprint-retro-tab.component.ts` | Just a loading shell — no changes needed |
| `sprint-vote-panel.component.ts` | Sprint MVP vote — separate feature, unrelated |
| `retro-card.model.ts` | Complete and correct |
| `retro-card.service.ts` | Complete and correct |
| All phase/board/stepper/spotlight logic | Already matches the design recommendation exactly |

---

## What already works — don't touch

- **Phase flow** — `advancePhase()` / `regressPhase()` + `updatePhase()` API call
- **Real-time card sync** — WebSocket events handled in `ngOnInit`
- **Vote budget** — `budget = computed(() => 3 - cards.reduce(myVoteCount))` is correct
- **Spotlight / discuss queue** — `discussionQueue` computed signal, `spotlightIndex` signal
- **Mobile tab switching** — `mobileCol` signal, column tab buttons
- **Convert card → action** — `convertToAction(card)` works correctly (creates a `RetroAction`)
- **Status cycle** — Open → InProgress → Done cycles correctly
- **Delete card** — author-only guard (`card.authorId === currentMemberId`) is correct

---

## Design reference

The wireframe file (`Retro Flow Wireframes.html`) shows four session-flow concepts.
Concepts A and B are what's already in production. The wireframes are visual references
only — do not copy their HTML/CSS. Apply the app's existing dark theme
(`background: #0f1117`, Angular Material dark, Geist font, existing component styles).

---

## Testing the conversion flow

1. Run a retro through to the **Actions** phase
2. Add an action item, assign an owner (select from sprint members)
3. Click **→ Create task**
4. Verify the action shows **✓ Task created** and the button disappears
5. Navigate to the sprint member's task list — the work item should appear with type `Task`,
   status `Planned`, title matching the action
6. Verify the WebSocket broadcasts `retro_action_converted` so other open sessions update live


---

## Feature Ideas (enhancement backlog)

See `Retro Feature Ideas.html` for wireframes of all ideas below.

### 🚀 Ship first (low effort, high impact)

| Feature | Phase | What it does |
|---|---|---|
| **Phase timer** | All | Optional countdown per phase, visible to room. Facilitator controls pause/extend. Progress bar in phase header. |
| **Previous actions check-in** | Lobby | Shows last sprint's RetroActions colour-coded by status. Unresolved ones can be marked Done or carried forward (auto-added to this sprint's actions list). |
| **Icebreaker** | Lobby | Random question from a curated pool shown while people join. Answers visible live. Acts as a soft presence check. |
| **Emoji reactions** | Add/Discuss | 👍 😅 🔥 😬 💯 picker on each card. Separate from vote dots — don't affect discussion order. Collapsed to +N beyond 3. |
| **Action follow-up nudge** | Actions | When assigning an action, owner opts in to a mid-sprint reminder via the app's existing notification system. Links directly to the work item. |

### 📅 Next sprint (medium effort)

| Feature | Phase | What it does |
|---|---|---|
| **Anonymous mode** | Add | Facilitator toggle per session. Author stored server-side, never sent to clients until facilitator triggers reveal at Discuss phase. |
| **Typing presence** | Add | WebSocket broadcast when someone starts typing in a column input. Shows avatar + animated dots under that column. Debounced 400ms, cleared on submit or 3s idle. |
| **AI retro summary** | Actions | On session finish, AI reads all cards + actions and produces a 3-paragraph digest (key themes, what went well, action plan). Sent to participants. The `ai-prompts` service already exists in the codebase. |
| **Mood pulse** | Lobby | Anonymous 1–5 emoji slider before retro starts. Shows team avg to facilitator. Feeds into a health trend across sprints. |
| **Discussion nudge** | Discuss | After configurable time on one card (e.g. 3 min), card border turns amber and two options appear: "→ Action & move on" or "Keep 2 more min." |
| **Retro streak** | Lobby | Consecutive-retro attendance badge per participant. Shown as a 🔥N badge on avatars in the lobby. |
| **Card focus view** | All | Tap any card to expand into a detail panel (bottom sheet mobile / side drawer desktop). Full text, author, reactions, notes field, link-ticket, → action. |

### 🔬 Research first (high effort / AI)

| Feature | Phase | What it does |
|---|---|---|
| **AI card grouping** | Vote | Before voting, AI flags clusters of semantically similar cards. Facilitator merges or dismisses. Merged cards pool vote counts. Requires embedding model. |
| **Repeat theme alert** | Add | As cards are submitted, AI compares to historical retro cards for this team. Surfaces a "🔄 came up in Sprint X" badge if a near-match found. Requires historical embeddings store. |
| **Cluster canvas** | Discuss | Optional grouping step between Vote and Discuss. Board goes freeform — drag cards into named clusters. Discussion works cluster-by-cluster. |
| **AI action draft** | Discuss | After each discussed card, AI drafts a concrete action item. Facilitator taps "Use this" to add pre-filled. Always editable before saving. |
| **Queue manager** | Discuss | Facilitator can drag-reorder the vote-sorted discussion queue, or skip cards to a "parked" section at the end. |

### Priority logic
These features were prioritised against three root problems:
- **Action items get forgotten** → Previous actions check-in, follow-up nudge, AI summary
- **Discussion runs over time** → Phase timer, discussion nudge, queue manager
- **Retros feel repetitive/boring** → Icebreaker, emoji reactions, mood pulse, streak
