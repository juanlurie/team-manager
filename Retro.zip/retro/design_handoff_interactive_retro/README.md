# Handoff: Interactive Sprint Retro

## Overview
An **interactive, real-time sprint retrospective** that a team runs together — on phones or desktops at the same time. Participants add cards live under three columns (Went well / Didn't go well / Action items), spend a small budget of votes to surface what matters, discuss the top items, and turn action items into **assigned tasks** in the host system.

The session is **hybrid-facilitated**: one person (the facilitator) drives the phase the room is in, but anyone can add cards at any time. All cards appear **live** as they are typed, attributed to their author.

This handoff covers the **recommended direction** chosen after a wireframe exploration of four session-flow concepts. See "Recommended Direction" below.

---

## About the Design Files
The files in this bundle are **design references created in HTML** — low-fidelity wireframe prototypes that communicate structure, flow, and intended behavior. **They are not production code to copy directly.**

The task is to **recreate these designs inside the target codebase's existing environment** (the screenshots show an existing dark-themed React/web product with a tabbed sprint view: Members / Workload / Retro / Vote). Use that app's established component library, styling system, state layer, and data models. Do **not** lift the HTML/CSS verbatim — it is a sketch, deliberately rough.

If no front-end environment exists yet, choose the framework most appropriate for the project and implement there.

---

## Fidelity
**Low-fidelity (lofi).** These are wireframes showing layout, flow, and interaction structure — drawn in a sketchy hand-drawn style on purpose. Colors and type in the wireframes are placeholders for communication only.

- **Use the wireframes for:** screen structure, the phase flow, what's on each screen, voting mechanics, the action-item→task model, and responsive behavior (desktop vs phone).
- **Apply your codebase's real design system for:** actual colors, typography, spacing, components, dark theme, iconography. Match the existing Retro tab styling shown in the screenshots (dark navy background `~#0e1726`, green/amber/pink column accents, the orange ⚡ floating button).

---

## Recommended Direction

After exploring four concepts (A Guided Stepper, B Living Board, C Stage + Phone, D One Long Page), the recommendation is a **responsive hybrid**:

| Viewport | Concept | Behavior |
|---|---|---|
| **Desktop** | **B — Living Board** | The existing three-column board stays visible the whole time. A mode control (the ⚡ button) switches the board between **Add → Vote → Discuss** modes. Cards never disappear. |
| **Phone** | **A — Guided Stepper** | The same session, but **one phase fills the screen at a time** (Join → Add → Vote → Discuss → Actions) so there is no pinch-zooming a 3-column board on a small screen. |

Both are **the same live session and the same data** — this is responsive behavior driven by viewport, not two separate products. A user on desktop and a user on phone are in the same retro, seeing the same cards and votes update in real time.

Concepts **C** and **D** were explored but are **out of scope for v1** (C needs a shared room screen; D's ungated scroll loses the "together" feel). They remain in the wireframe file for reference only.

---

## The Session Flow (shared spine)

All phases operate on the same three columns. The facilitator advances the phase for the room; phase state is shared.

1. **Lobby / Join** — participants gather; facilitator sees who's present and presses **Start**.
2. **Add items** — everyone types cards into any of the three columns. Cards appear live for all participants, tagged with the author. Anyone can keep adding in later phases too (hybrid rule).
3. **Vote** — each participant gets **3 vote dots** to spend across any cards (multiple dots may be placed on one card). A running "dots left" indicator is shown. Vote tallies update live.
4. **Discuss** — cards are ordered by votes; the top-voted card is spotlighted ("Now discussing"), the rest queue below. A timer is optional. From a discussed card, the facilitator can **"Turn into action."**
5. **Action items → tasks** — each action item is given an **owner** (assignee) chosen from the sprint's members, and becomes a **task in the host system**. A summary is saved at the end.

---

## Screens / Views

### Shared building blocks
- **Three columns**, fixed for v1:
  - **Went well** — accent green. Prompt: "What went well this sprint?"
  - **Didn't go well** — accent amber. Prompt: "What could've gone better?"
  - **Action items** — accent pink. Created during discussion; each gets an owner.
- **Card**: short text + author avatar/name. In Vote mode, gains a vote-dot control + count. In Discuss mode, can be spotlighted/dimmed.
- **Phase/mode control**: drives which phase the room is in. On desktop this is the ⚡ control in the toolbar; on phone it's the stepper's Next/Back (facilitator-gated).
- **Vote budget indicator**: "3 dots left" → decrements as dots are spent; can be reclaimed by un-voting.

### Desktop — Living Board (Concept B)
- **Add mode**: three-column board with an inline "+ add…" input at the foot of each column. Toolbar shows current mode (⚡ Add).
- **Vote mode**: same board; each card shows tappable vote dots and its current count; toolbar shows mode + dots remaining.
- **Discuss mode**: same board; top-voted card is emphasized (heavier border / highlight), others dimmed; a side "discussion queue" lists remaining items by vote count. "+ from card" creates an action.
- **Assign owner**: clicking an action item opens an owner picker (popover) listing sprint members with avatars. Selected owner shows on the card.
- **Tasks view**: action items appear as tasks with owner + status (e.g. To do). These are the tasks created in the host system.

### Phone — Guided Stepper (Concept A)
- **Lobby**: session title + dates, list/avatars of who's present, step pips (1–4), **Start** button (facilitator only).
- **Add (step 2)**: the three columns shown compactly with per-column add inputs; timer optional; cards appear live with author.
- **Vote (step 3)**: vertical list of cards, each with a dot control and count; "3 dots left" chip; spend up to 3.
- **Discuss (step 4)**: spotlight card ("Now discussing") with vote count and a **"Turn into action"** button; "Up next" list dimmed below; optional timer.
- **Actions (step 5)**: list of action items, each with **assign owner ▾**; **Finish & save summary** button.

---

## Interactions & Behavior
- **Live updates**: card creation, edits, and votes broadcast to all participants in real time (WebSocket / realtime channel). Use the app's existing realtime layer.
- **Add card**: focus input → type → submit (Enter) → card appears for everyone, attributed to author. Empty submissions ignored.
- **Voting**: tap a card's dot control to add a vote (if budget > 0); tap again to remove. Enforce per-user max of 3 total. Live tally per card.
- **Phase advance**: facilitator-only control moves the room forward/back. Non-facilitators' views follow. Adding cards remains allowed in all phases (hybrid).
- **Discuss spotlight**: facilitator steps through cards in vote-descending order; current card emphasized, others dimmed.
- **Create action**: from a discussed card or the Action column input; opens with optional link back to the source card.
- **Assign owner**: opens a member picker; selecting sets the assignee and (on finish) creates/links a task.
- **Finish**: saves a session summary and ensures all action items exist as tasks.
- **Responsive switch**: desktop ≥ ~900px → Living Board; below → Guided Stepper. Same session/state underneath.

## State Management
Needed state (wire to the app's existing store / server):
- `session`: id, sprint ref, dates, phase (`lobby | add | vote | discuss | actions | done`), facilitatorId.
- `participants[]`: id, name, avatar, presence.
- `cards[]`: id, columnId (`well | better | action`), text, authorId, createdAt, votes (map of userId→count or array), sourceCardId (for actions).
- `currentUser`: id, votesRemaining (derived: 3 − dots spent), isFacilitator.
- `discussion`: currentCardId, queue order (derived from vote counts).
- `actionItems[]`: id, text, ownerId, status, sourceCardId.
- Realtime triggers: add/edit/delete card, cast/retract vote, change phase, spotlight card, create/assign action, finish session.

## Design Tokens
Wireframe placeholders — **replace with the codebase's real dark-theme tokens** (match the Retro tab in the screenshots):
- **Column accents**: Went well ≈ green; Didn't go well ≈ amber; Action items ≈ pink/magenta; live/vote ≈ blue. Floating action button ≈ orange (⚡).
- **Surface**: dark navy app background; slightly lighter card/panel surfaces; subtle borders.
- **Type**: use the app's existing font stack; column headers are small uppercase labels with an icon; card text is regular body size.
- **Hit targets**: minimum 44px on phone (vote dots, add buttons, owner picker rows).
- Spacing / radius / shadow: use the existing system.

## Assets
- No bespoke assets required. Icons (members, workload, retro, vote, gear, ⚡, column glyphs) should come from the app's existing icon set.
- The sketchy fonts (Caveat, Patrick Hand) used in the wireframes are **for the wireframe only** — do not ship them.

## Files
In this bundle:
- `Retro Flow Wireframes.html` — the interactive wireframe with all four concepts (tab A/B/C/D). **B and A are the recommended pair.** Includes a Tweaks panel (font/accents/grid/phone-frame toggles) that is wireframe-only.
- `sketch.css` — wireframe styling (reference only; do not ship).
- `tweaks-panel.jsx` — supports the wireframe's tweak controls (reference only; do not ship).
- `Screenshot 2026-05-30 150148.png` — the existing product's Retro tab, the visual target to match.

Open `Retro Flow Wireframes.html` in a browser and switch between concept tabs to walk each storyboard.
