console.log("[CookieHelper] Content script loaded on", window.location.href);

function pushCookies() {
  chrome.runtime.sendMessage({ action: "getAllCookies" }, (response) => {
    const values = response?.values || {};
    for (const [storageKey, value] of Object.entries(values)) {
      if (value) {
        console.log("[CookieHelper] Writing", storageKey, "to localStorage");
        localStorage.setItem(storageKey, value);
      } else {
        console.warn("[CookieHelper] No value for", storageKey, "— removing from localStorage");
        localStorage.removeItem(storageKey);
      }
    }
  });
}

pushCookies();

window.addEventListener("message", (e) => {
  if (e.source !== window) return;
  if (e.data?.type === "request-cookies") {
    console.log("[CookieHelper] Received request-cookies, pushing cookies");
    pushCookies();
  }
});
