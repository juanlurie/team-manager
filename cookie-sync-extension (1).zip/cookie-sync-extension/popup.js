// --- Cookie configs: multiple {label, source domain, cookie name, storage key} rules ---

const cookieListEl = document.getElementById("cookie-list");
const cookieMsgEl = document.getElementById("cookie-msg");
const addCookieBtn = document.getElementById("add-cookie-btn");
const cfgLabelEl = document.getElementById("cfg-label");
const cfgSourceEl = document.getElementById("cfg-source");
const cfgCookieNameEl = document.getElementById("cfg-cookie-name");
const cfgStorageKeyEl = document.getElementById("cfg-storage-key");

function setCookieMsg(text, ok) {
  cookieMsgEl.textContent = text;
  cookieMsgEl.className = ok ? "ok" : "err";
  if (text) setTimeout(() => { cookieMsgEl.textContent = ""; cookieMsgEl.className = ""; }, 3000);
}

function renderCookieList(status) {
  cookieListEl.innerHTML = "";
  if (!status.length) {
    cookieListEl.innerHTML = '<div class="sub" style="font-size:11px;color:#888;margin-bottom:4px">No cookies configured</div>';
    return;
  }
  for (const cfg of status) {
    const card = document.createElement("div");
    card.className = "cookie-card";

    const row1 = document.createElement("div");
    row1.className = "row1";
    const label = document.createElement("span");
    label.className = "label";
    label.textContent = cfg.label;
    const badge = document.createElement("span");
    badge.textContent = cfg.hasValue ? "Found" : "Not found";
    badge.className = cfg.hasValue ? "ok" : "none";
    row1.appendChild(label);
    row1.appendChild(badge);

    const meta = document.createElement("div");
    meta.className = "meta";
    meta.textContent = `${cfg.cookieName} @ ${cfg.sourceDomain} → localStorage["${cfg.storageKey}"]`;

    const actions = document.createElement("div");
    actions.className = "actions";
    const copyBtn = document.createElement("button");
    copyBtn.textContent = "Copy";
    copyBtn.disabled = !cfg.hasValue;
    copyBtn.onclick = () => {
      navigator.clipboard.writeText(cfg.value).then(() => {
        copyBtn.textContent = "Copied!";
        setTimeout(() => { copyBtn.textContent = "Copy"; }, 1200);
      });
    };
    const rmBtn = document.createElement("button");
    rmBtn.textContent = "Remove";
    rmBtn.className = "rm-btn";
    rmBtn.onclick = () => deleteCookieConfig(cfg.id);
    actions.appendChild(copyBtn);
    actions.appendChild(rmBtn);

    card.appendChild(row1);
    card.appendChild(meta);
    card.appendChild(actions);
    cookieListEl.appendChild(card);
  }
}

function refreshCookieList() {
  chrome.runtime.sendMessage({ action: "getStatus" }, (response) => {
    renderCookieList(response?.status || []);
  });
}

async function deleteCookieConfig(id) {
  chrome.runtime.sendMessage({ action: "deleteConfig", id }, (response) => {
    renderCookieList(response?.status || []);
  });
}

addCookieBtn.onclick = async () => {
  const label = cfgLabelEl.value.trim();
  const sourceDomain = cfgSourceEl.value.trim().replace(/^https?:\/\//i, "").replace(/\/.*$/, "");
  const cookieName = cfgCookieNameEl.value.trim();
  const storageKey = cfgStorageKeyEl.value.trim();

  if (!label || !sourceDomain || !cookieName || !storageKey) {
    setCookieMsg("Fill in all fields", false);
    return;
  }

  // Reading cookies for a domain via chrome.cookies requires host permission for it.
  const granted = await chrome.permissions.request({
    origins: [`https://${sourceDomain}/*`, `http://${sourceDomain}/*`]
  });
  if (!granted) {
    setCookieMsg("Permission denied for that domain", false);
    return;
  }

  chrome.runtime.sendMessage(
    { action: "saveConfig", config: { label, sourceDomain, cookieName, storageKey } },
    (response) => {
      renderCookieList(response?.status || []);
      cfgLabelEl.value = "";
      cfgSourceEl.value = "";
      cfgCookieNameEl.value = "";
      cfgStorageKeyEl.value = "";
      setCookieMsg("Cookie added", true);
    }
  );
};

refreshCookieList();

// --- Custom domains: add/remove sites at runtime without editing the extension ---

const domainListEl = document.getElementById("domain-list");
const domainInputEl = document.getElementById("domain-input");
const domainMsgEl = document.getElementById("domain-msg");
const addCurrentBtn = document.getElementById("add-current-btn");

const STORAGE_KEY = "customDomains";

function scriptIdFor(pattern) {
  return "dyn-" + pattern.replace(/[^a-zA-Z0-9]/g, "_");
}

// Accepts "localhost:8081", "http://localhost:8081", "https://team.example.com/app", etc.
function parseOrigin(raw) {
  let s = raw.trim();
  if (!s) return null;
  if (!/^https?:\/\//i.test(s)) s = "http://" + s;
  try {
    const u = new URL(s);
    return `${u.protocol}//${u.host}/*`;
  } catch {
    return null;
  }
}

async function getCustomDomains() {
  const data = await chrome.storage.local.get(STORAGE_KEY);
  return data[STORAGE_KEY] || [];
}

async function setCustomDomains(list) {
  await chrome.storage.local.set({ [STORAGE_KEY]: list });
}

function setMsg(text, ok) {
  domainMsgEl.textContent = text;
  domainMsgEl.className = ok ? "ok" : "err";
  if (text) setTimeout(() => { domainMsgEl.textContent = ""; domainMsgEl.className = ""; }, 3000);
}

async function renderDomainList() {
  const domains = await getCustomDomains();
  domainListEl.innerHTML = "";
  if (domains.length === 0) {
    domainListEl.innerHTML = '<div class="sub" style="font-size:11px;color:#888;margin-bottom:4px">None added yet</div>';
    return;
  }
  for (const pattern of domains) {
    const row = document.createElement("div");
    row.className = "domain-row";
    const label = document.createElement("span");
    label.textContent = pattern;
    const removeBtn = document.createElement("button");
    removeBtn.textContent = "Remove";
    removeBtn.onclick = () => removeDomain(pattern);
    row.appendChild(label);
    row.appendChild(removeBtn);
    domainListEl.appendChild(row);
  }
}

async function addDomain(pattern, tabIdToInjectNow) {
  const granted = await chrome.permissions.request({ origins: [pattern] });
  if (!granted) {
    setMsg("Permission denied", false);
    return;
  }

  // persistAcrossSessions isn't universally accepted (Firefox's scripting.registerContentScripts
  // implementation has historically been stricter about unknown fields) — retry without it
  // rather than letting registration fail outright on a browser that rejects the property.
  try {
    await chrome.scripting.registerContentScripts([{
      id: scriptIdFor(pattern),
      matches: [pattern],
      js: ["content.js"],
      runAt: "document_idle",
      persistAcrossSessions: true
    }]);
  } catch {
    await chrome.scripting.registerContentScripts([{
      id: scriptIdFor(pattern),
      matches: [pattern],
      js: ["content.js"],
      runAt: "document_idle"
    }]);
  }

  const domains = await getCustomDomains();
  if (!domains.includes(pattern)) {
    domains.push(pattern);
    await setCustomDomains(domains);
  }

  if (tabIdToInjectNow != null) {
    try {
      await chrome.scripting.executeScript({ target: { tabId: tabIdToInjectNow }, files: ["content.js"] });
      setMsg("Added — cookie synced on this page", true);
    } catch {
      setMsg("Added — reload the page to sync", true);
    }
  } else {
    setMsg("Added — reload the target page to sync", true);
  }

  domainInputEl.value = "";
  renderDomainList();
}

async function removeDomain(pattern) {
  try {
    await chrome.scripting.unregisterContentScripts({ ids: [scriptIdFor(pattern)] });
  } catch { /* may already be gone */ }
  try {
    await chrome.permissions.remove({ origins: [pattern] });
  } catch { /* host permission shared elsewhere, ignore */ }

  const domains = (await getCustomDomains()).filter(d => d !== pattern);
  await setCustomDomains(domains);
  renderDomainList();
}

addCurrentBtn.onclick = async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.url) { setMsg("Couldn't read the current tab", false); return; }
  const pattern = parseOrigin(tab.url);
  if (!pattern) { setMsg("Current tab has no addressable URL", false); return; }
  await addDomain(pattern, tab.id);
};

domainInputEl.addEventListener("keydown", (e) => {
  if (e.key !== "Enter") return;
  const pattern = parseOrigin(domainInputEl.value);
  if (!pattern) { setMsg("Enter a valid domain", false); return; }
  addDomain(pattern, null);
});

renderDomainList();
