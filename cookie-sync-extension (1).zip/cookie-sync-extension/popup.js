const statusEl = document.getElementById("status");
const updatedEl = document.getElementById("updated");
const copyBtn = document.getElementById("copy-btn");

chrome.runtime.sendMessage({ action: "getCookie" }, (response) => {
  if (response?.value) {
    statusEl.textContent = "Cookie found";
    statusEl.className = "ok";
    updatedEl.textContent = "Fetched at " + new Date().toLocaleTimeString();
    copyBtn.onclick = () => {
      navigator.clipboard.writeText(response.value).then(() => {
        copyBtn.textContent = "Copied!";
        setTimeout(() => copyBtn.textContent = "Copy Cookie Value", 1500);
      });
    };
  } else {
    statusEl.textContent = "No cookie found";
    statusEl.className = "none";
    updatedEl.textContent = "Log into employee.entelect.co.za first";
    copyBtn.disabled = true;
  }
});
