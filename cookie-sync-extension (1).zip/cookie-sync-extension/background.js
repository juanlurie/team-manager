const CONFIGS_KEY = "cookieConfigs";
const VALUES_KEY = "cookieValues";

// Back-compat default: the original single Entelect auth cookie.
const DEFAULT_CONFIGS = [
  {
    id: "entelect-auth",
    label: "Entelect Auth",
    sourceDomain: "employee.entelect.co.za",
    cookieName: ".AspNet.Cookies",
    storageKey: "entelectCookie"
  }
];

async function getConfigs() {
  const data = await chrome.storage.local.get(CONFIGS_KEY);
  const configs = data[CONFIGS_KEY];
  if (configs && configs.length) return configs;
  await chrome.storage.local.set({ [CONFIGS_KEY]: DEFAULT_CONFIGS });
  return DEFAULT_CONFIGS;
}

async function setConfigs(configs) {
  await chrome.storage.local.set({ [CONFIGS_KEY]: configs });
}

async function getValues() {
  const data = await chrome.storage.local.get(VALUES_KEY);
  return data[VALUES_KEY] || {};
}

async function setValue(configId, value) {
  const values = await getValues();
  values[configId] = { value, updatedAt: new Date().toISOString() };
  await chrome.storage.local.set({ [VALUES_KEY]: values });
}

async function fetchCookieForConfig(cfg) {
  console.log("[CookieHelper] Fetching", cfg.cookieName, "from", cfg.sourceDomain);
  const cookie = await chrome.cookies.get({ url: "https://" + cfg.sourceDomain, name: cfg.cookieName });
  return cookie ? cookie.value : null;
}

async function refreshConfig(cfg) {
  const value = await fetchCookieForConfig(cfg);
  await setValue(cfg.id, value);
  return value;
}

async function refreshAll() {
  const configs = await getConfigs();
  const byStorageKey = {};
  for (const cfg of configs) {
    byStorageKey[cfg.storageKey] = await refreshConfig(cfg);
  }
  return byStorageKey;
}

async function getStatusForAll() {
  const configs = await getConfigs();
  const values = await getValues();
  return configs.map((cfg) => ({
    id: cfg.id,
    label: cfg.label,
    sourceDomain: cfg.sourceDomain,
    cookieName: cfg.cookieName,
    storageKey: cfg.storageKey,
    hasValue: !!values[cfg.id]?.value,
    value: values[cfg.id]?.value || null,
    updatedAt: values[cfg.id]?.updatedAt || null
  }));
}

function newId() {
  return "cfg-" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
}

async function saveConfig(partial) {
  const configs = await getConfigs();
  let cfg = partial.id ? configs.find((c) => c.id === partial.id) : null;
  if (cfg) {
    Object.assign(cfg, partial);
  } else {
    cfg = {
      id: newId(),
      label: partial.label,
      sourceDomain: partial.sourceDomain,
      cookieName: partial.cookieName,
      storageKey: partial.storageKey
    };
    configs.push(cfg);
  }
  await setConfigs(configs);
  await refreshConfig(cfg);
  return getStatusForAll();
}

async function deleteConfig(id) {
  const configs = (await getConfigs()).filter((c) => c.id !== id);
  await setConfigs(configs);
  const values = await getValues();
  delete values[id];
  await chrome.storage.local.set({ [VALUES_KEY]: values });
  return getStatusForAll();
}

chrome.cookies.onChanged.addListener(async (change) => {
  const configs = await getConfigs();
  for (const cfg of configs) {
    if (change.cookie.domain.includes(cfg.sourceDomain) && change.cookie.name === cfg.cookieName) {
      console.log("[CookieHelper]", cfg.label, "changed, removed:", change.removed);
      await setValue(cfg.id, change.removed ? null : change.cookie.value);
    }
  }
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  switch (msg.action) {
    case "getCookie": {
      // Legacy single-cookie path, kept for older content scripts.
      fetchCookieForConfig(DEFAULT_CONFIGS[0]).then((value) => {
        if (value) setValue(DEFAULT_CONFIGS[0].id, value);
        sendResponse({ value });
      });
      return true;
    }
    case "getAllCookies": {
      refreshAll().then((values) => sendResponse({ values }));
      return true;
    }
    case "getStatus": {
      getStatusForAll().then((status) => sendResponse({ status }));
      return true;
    }
    case "saveConfig": {
      saveConfig(msg.config).then((status) => sendResponse({ status }));
      return true;
    }
    case "deleteConfig": {
      deleteConfig(msg.id).then((status) => sendResponse({ status }));
      return true;
    }
  }
  return false;
});
