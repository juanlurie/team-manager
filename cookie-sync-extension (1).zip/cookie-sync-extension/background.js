const SOURCE_DOMAIN = "employee.entelect.co.za";
const COOKIE_NAME = ".AspNet.Cookies";

async function getEntelectCookie() {
  console.log("[CookieHelper] Fetching cookie from", SOURCE_DOMAIN);
  const cookie = await chrome.cookies.get({
    url: "https://" + SOURCE_DOMAIN,
    name: COOKIE_NAME
  });
  if (cookie) {
    console.log("[CookieHelper] Cookie found, length:", cookie.value.length);
  } else {
    console.warn("[CookieHelper] Cookie not found on", SOURCE_DOMAIN);
  }
  return cookie ? cookie.value : null;
}

chrome.cookies.onChanged.addListener(async (change) => {
  if (
    change.cookie.domain.includes(SOURCE_DOMAIN) &&
    change.cookie.name === COOKIE_NAME
  ) {
    console.log("[CookieHelper] Cookie changed, removed:", change.removed);
    const value = change.removed ? null : change.cookie.value;
    await chrome.storage.local.set({ entelectCookie: value, updatedAt: new Date().toISOString() });
  }
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.action === "getCookie") {
    console.log("[CookieHelper] getCookie message received");
    getEntelectCookie().then((value) => {
      if (value) chrome.storage.local.set({ entelectCookie: value, updatedAt: new Date().toISOString() });
      sendResponse({ value });
    });
    return true;
  }
});
