console.log("[CookieHelper] Content script loaded on", window.location.href);

function pushCookies() {
  chrome.runtime.sendMessage({ action: "getAllCookies" }, (response) => {
    const values = response?.values || {};
    for (const [storageKey, value] of Object.entries(values)) {
      if (value) {
        console.log("[CookieHelper] Writing", storageKey, "to localStorage");
        localStorage.setItem(storageKey, value);
      } else {
        console.warn("[CookieHelper] No value for", storageKey, "— removing from localStorage");
        localStorage.removeItem(storageKey);
      }
    }
  });
}

// Push all configured cookies immediately when content script loads
pushCookies();

// Also push on explicit request (belt and suspenders).
// "request-entelect-cookie" is kept for pages built against the old single-cookie API.
window.addEventListener("message", (e) => {
  if (e.source !== window) return;
  if (e.data?.type === "request-cookies" || e.data?.type === "request-entelect-cookie") {
    console.log("[CookieHelper] Received", e.data.type, "pushing cookies");
    pushCookies();
  }
});
