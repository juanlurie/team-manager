console.log("[CookieHelper] Content script loaded on", window.location.href);

function pushCookie() {
  chrome.runtime.sendMessage({ action: "getCookie" }, (response) => {
    if (response?.value) {
      console.log("[CookieHelper] Cookie found, writing to localStorage");
      localStorage.setItem("entelectCookie", response.value);
    } else {
      console.warn("[CookieHelper] No cookie found — is the user logged into employee.entelect.co.za?");
      localStorage.removeItem("entelectCookie");
    }
  });
}

// Push cookie immediately when content script loads
pushCookie();

// Also push on explicit request (belt and suspenders)
window.addEventListener("message", (e) => {
  if (e.source === window && e.data?.type === "request-entelect-cookie") {
    console.log("[CookieHelper] Received request-entelect-cookie, pushing cookie");
    pushCookie();
  }
});
