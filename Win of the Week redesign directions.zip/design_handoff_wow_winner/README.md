# Handoff: Win of the Week — Winner Reveal Redesign

## Overview
A redesigned "winner" state for the existing Win of the Week feature: a confetti burst, a spinning gold trophy ring, and a runners-up row, replacing the current plain `app-wow-winner-banner`. Voting-state styling was also explored but **only the winner screen is in scope for this handoff.**

## About the Design Files
The bundled HTML file is a **design reference built as a standalone prototype**, not production code to copy in. It's plain HTML/CSS/JS with inline styles and no Angular — the task is to recreate this look and animation inside the existing Angular codebase (`team-manager-ui`), using its real components, signals, and `--ds-*` design tokens, not to paste the HTML in directly.

## Fidelity
**High-fidelity.** Colors, radii, spacing, and animation timing below are final — implement pixel-for-pixel where they don't conflict with existing token values.

## Target in the codebase
This replaces the winner-state visuals currently rendered by:
- `team-manager-ui/src/app/shared/components/wow-winner-banner/wow-winner-banner.component.ts` — the whole template's visual container needs the new treatment (trophy ring, confetti, runners-up). Keep all existing `@Input`s (`winnerNomineeName`, `winnerTitle`, `winnerStory`, `showPoints`), all share/copy/download button logic, and the `copyStory` output — none of that behavior changes, only the surrounding chrome.
- Rendered from `wow-current-week.component.ts`, in the `@if (w && w.status === 'Closed' && w.winnerNomineeName)` block. That call site is unchanged; it still just passes the same inputs to `<app-wow-winner-banner>`.
- **New:** runners-up row is new — it doesn't exist in the current banner. Data for it (2nd/3rd place nominees by vote count) is available in the parent via `WinWeek.nominations` (sorted by `voteCount`); pass the top 3 non-winner nominations down as a new `@Input() runnersUp: { name: string; voteCount: number }[]` (or compute it inside `WowCurrentWeekComponent` and pass just the array).

## Screens / Views

### Winner Reveal (single view)
**Purpose:** Shown when a Win of the Week closes and a winner is set. Celebrates the winner and shows the runner-up field.

**Layout:** Single card, full width of its container (matches the existing banner's container). Padding `26px 18px`. `border-radius: 16px`. Vertically stacked, centered, `text-align: center`.

**Components, top to bottom:**

1. **Container**
   - `background: radial-gradient(120% 100% at 50% -10%, rgba(245,197,66,0.18), rgba(245,197,66,0.03) 60%)`
   - `border: 1px solid rgba(245,197,66,0.35)`
   - `position: relative; overflow: hidden` (so confetti clips to the rounded corners)

2. **Confetti layer** (absolute, `inset:0`, `pointer-events:none`, sits behind content but above the background — content that needs to stay above it uses `z-index:1`)
   - 7 `<span>`s, each `width:6px; height:10px`, positioned at `left: 8%, 20%, 34%, 48%, 62%, 76%, 90%` respectively, colors cycling through `#f5c542` (gold), `#5b9df0` (primary blue), `#e8628d` (accent pink), `#45b97c` (success green), `#b083e6` (info purple) — reuse the existing `--ds-*` semantic palette, don't invent new colors.
   - Animation: `confettiFall 2.6s ease-in infinite`, staggered `animation-delay` per span: `0s, 0.3s, 0.6s, 0.15s, 0.45s, 0.75s, 0.9s`.
   - Keyframes:
     ```css
     @keyframes confettiFall {
       0%   { transform: translateY(-40px) rotate(0deg); opacity: 0; }
       10%  { opacity: 1; }
       100% { transform: translateY(220px) rotate(220deg); opacity: 0; }
     }
     ```

3. **Trophy ring**
   - Outer: `76px × 76px` circle, `background: conic-gradient(from 0deg, #f5c542, #fff3c4, #f5c542)`, `box-shadow: 0 0 30px rgba(245,197,66,0.4)`, centered, `margin: 0 auto 12px`.
   - Animation: continuous spin, `animation: ringSpin 6s linear infinite` (`@keyframes ringSpin { to { transform: rotate(360deg); } }`).
   - Inner: `64px × 64px` circle, `background: #12141b` (near the app's `--ds-surface-sunken`), centered inside the outer ring, containing the 🏆 emoji at `font-size: 1.8rem`.

4. **Winner name** — existing `winnerNomineeName` input. `font-weight: 800; font-size: 1.1rem`.

5. **Winner title** — existing `winnerTitle` input, when present. `font-size: 0.85rem; color: var(--ds-text-muted); margin-top: 2px`.

6. **Points chip** — existing "Weekly Champion +10 points" chip, keep as-is (`background: rgba(245,197,66,0.15); border: 1px solid rgba(245,197,66,0.4); color: var(--ds-gold)`), just add `position: relative; z-index: 1` so it renders above the confetti layer.

7. **Runners-up row (NEW)**
   - Flex row, `gap: 8px`, `margin-top: 16px`, `position: relative; z-index: 1`.
   - One card per runner-up (2nd, then 3rd place — up to 2 cards), each `flex: 1`.
   - Card style: `background: rgba(255,255,255,0.03); border: 1px solid var(--ds-border); border-radius: 10px; padding: 9px; font-size: 0.72rem; text-align: center; color: var(--ds-text-muted)`.
   - Content: medal emoji (🥈 for 2nd, 🥉 for 3rd) + name on line 1, vote count ("N votes") on line 2.
   - If there's only 1 other nomination, show just 1 card. If there are none, omit the row entirely.

8. **Existing winner story block + share/copy/download/WhatsApp buttons** — unchanged, keep exactly as implemented today in `wow-winner-banner.component.ts`. Just ensure they render below the new runners-up row and inherit `z-index: 1` if the confetti layer would otherwise sit above them (it shouldn't, since confetti is `pointer-events:none` and z-index 0, but double check when integrating).

9. Existing footer caption "Winner of the Week" — unchanged.

## Interactions & Behavior
- No new click handlers. The trophy ring spin and confetti fall are ambient/looping CSS animations that start as soon as the winner view mounts — no trigger needed, no exit condition (they just loop for as long as the winner card is visible).
- Respect `prefers-reduced-motion`: wrap the two `animation` declarations (ring spin, confetti fall) in `@media (prefers-reduced-motion: no-preference)` so motion-sensitive users get the static gold ring + no confetti instead. This wasn't in the prototype but should be added for production.
- All existing share/copy/download interaction logic in `wow-winner-banner.component.ts` (`copyImage()`, `shareImage()`, `shareWhatsApp()`, `downloadImage()`) is unchanged.

## State Management
- No new component state needed beyond the new `runnersUp` input described above. Everything else (loading/copying/sharing/downloading signals) already exists in `WowWinnerBannerComponent`.
- `runnersUp` should be computed where `WowCurrentWeekComponent` already has `sortedNominations()` / `week()` — take the closed week's `nominations`, sort by `voteCount` descending, drop the winner, take the next 2.

## Design Tokens
Use existing `--ds-*` tokens wherever they map, don't hardcode where a token exists:
- Gold accent (trophy, confetti, points chip): `--ds-gold` (`#f5c542`)
- Confetti secondary colors: `--ds-primary` `#5b9df0`, `--ds-accent` `#e8628d`, `--ds-success` `#45b97c`, `--ds-info` `#b083e6`
- Muted text: `--ds-text-muted` (`#9aa6b8`)
- Card border/bg for runners-up: `--ds-border` (`rgba(255,255,255,0.08)`)
- Radius: card `--ds-radius-lg` (16px scale — close to the `16px` used), runners-up card ~`--ds-radius-sm`/`md` (10-12px)
- Font: existing self-hosted Geist, no change

## Assets
No new image/icon assets — trophy and medal are emoji (🏆 🥈 🥉), confetti pieces are plain colored `<div>`s/`<span>`s, matching the rest of the feature's existing emoji-forward style (⭐ 🌶️ 🔥 etc. elsewhere in WoW).

## Files
- `win-of-the-week-prototype.html` (in this folder) — the interactive HTML prototype this spec was extracted from. Open it in a browser; use "End Voting & Reveal Winner" to see the winner state directly.
- `screenshots/voting-state.png` — voting phase (for context; not in scope for this handoff).
- `screenshots/winner-state.png` — the winner reveal screen this handoff describes.
